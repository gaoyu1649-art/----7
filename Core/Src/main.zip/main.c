/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2026 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "dma.h"
#include "tim.h"
#include "usart.h"
#include "gpio.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include "stm32f4xx_hal_uart.h"
#include <stdio.h>
#include <string.h>
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */

/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/

/* USER CODE BEGIN PV */

/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
/* USER CODE BEGIN PFP */

/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */
volatile uint32_t timer = 0;
char rec[50];
char HX[]="PWM";
int angle=500;
volatile uint32_t pwm_on=0;
uint32_t LEDTIME[3]={0,0,0};
static int32_t tim1=0,tim2=0,tim3=0;
static char bufR[16];
static char bufG[16];
static char bufB[16];



static int itc(uint32_t v, char *out)
{
  char tmp[10];
  int n = 0, k = 0;

  if (v == 0) { out[0] = '0'; return 1; }

  while (v > 0) { tmp[n++] = (char)('0' + v % 10); v /= 10; }
  while (n > 0) out[k++] = tmp[--n];
  return k;
}




void HAL_UARTEx_RxEventCallback(UART_HandleTypeDef *huart, uint16_t Size)
{


  if (huart->Instance == USART1) {

    HAL_UARTEx_ReceiveToIdle_DMA(&huart1, (uint8_t *)rec, sizeof(rec));
    __HAL_DMA_DISABLE_IT(huart1.hdmarx, DMA_IT_HT);

    if (rec[0]=='R'||rec[0]=='G'||rec[0]=='B') {
      if (Size<2) return;
      if (rec[1]=='1') {
        switch (rec[0]) {
          case 'R': HAL_GPIO_WritePin(LED_R_GPIO_Port, LED_R_Pin, GPIO_PIN_SET); LEDTIME[0]=HAL_GetTick();break;
          case 'G': pwm_on=0; __HAL_TIM_SET_COMPARE(&htim5, TIM_CHANNEL_2, 1000); LEDTIME[1]=HAL_GetTick();break;
          case 'B': HAL_GPIO_WritePin(LED_B_GPIO_Port, LED_B_Pin, GPIO_PIN_SET); LEDTIME[2]=HAL_GetTick();break;
        }
      }
      else if (rec[1]=='0') {
        switch (rec[0]) {
          case 'R':
            HAL_GPIO_WritePin(LED_R_GPIO_Port, LED_R_Pin, GPIO_PIN_RESET);
            int i = 0;
            tim1=(HAL_GetTick()-LEDTIME[0])/1000;
            i += itc(tim1, &bufR[i]);

            HAL_UART_Transmit_DMA(&huart1, (uint8_t *)bufR, (uint16_t)i);
            break;
          case 'G':
            pwm_on=0; __HAL_TIM_SET_COMPARE(&htim5, TIM_CHANNEL_2, 0);
            int j= 0;
            tim2=(HAL_GetTick()-LEDTIME[1])/1000;
            j += itc(tim2, &bufG[j]);

            HAL_UART_Transmit_DMA(&huart1, (uint8_t *)bufG, (uint16_t)j);
            break;
          case 'B':
            HAL_GPIO_WritePin(LED_B_GPIO_Port, LED_B_Pin, GPIO_PIN_RESET);
            int k = 0;
            tim3=(HAL_GetTick()-LEDTIME[2])/1000;
            k += itc(tim3, &bufB[k]);

            HAL_UART_Transmit_DMA(&huart1, (uint8_t *)bufB, (uint16_t)k);
            break;
        }
      }
    }


    if(Size==3) {
      if (!strncmp(rec,"PWM",3)) {
        pwm_on=1;
      }
    }

    if (Size>5) {
      char check[6]={0};
      int deg[3]={-1,-1,-1};
      int deg0;
      for (int i=0;i<5;i++) {
        check[i]=rec[i];
      }
      if (strcmp(check,"servo")==0) {
        for (int i=5;i<(int)Size-1&&i-5<3;i++) {
          deg[i-5]=rec[i]-'0';
        }

        if (deg[1]==-1) deg0=deg[0];
        else if (deg[2]==-1) deg0=deg[0]*10+deg[1];
        else  deg0=deg[0]*100+deg[1]*10+deg[2];

        if (deg0>180) {
          pwm_on=0; __HAL_TIM_SET_COMPARE(&htim5, TIM_CHANNEL_2, 0);
          HAL_GPIO_WritePin(LED_B_GPIO_Port, LED_B_Pin, GPIO_PIN_RESET);
          HAL_GPIO_WritePin(LED_R_GPIO_Port, LED_R_Pin, GPIO_PIN_SET);
          return;
        }


        if (rec[Size-1]=='L') {
          angle-=(deg0*2000/180);
          if (angle<500) angle=500;
        }
        else if (rec[Size-1]=='R') {
          angle+=(deg0*2000/180);
          if (angle>2500) angle=2500;
        }
        else {
          pwm_on=0; __HAL_TIM_SET_COMPARE(&htim5, TIM_CHANNEL_2, 0);
          HAL_GPIO_WritePin(LED_B_GPIO_Port, LED_B_Pin, GPIO_PIN_RESET);
          HAL_GPIO_WritePin(LED_R_GPIO_Port, LED_R_Pin, GPIO_PIN_SET);
          return;
        }

        __HAL_TIM_SET_COMPARE(&htim1, TIM_CHANNEL_1, angle);

      }
      else {
        pwm_on=0; __HAL_TIM_SET_COMPARE(&htim5, TIM_CHANNEL_2, 0);
        HAL_GPIO_WritePin(LED_B_GPIO_Port, LED_B_Pin, GPIO_PIN_RESET);
        HAL_GPIO_WritePin(LED_R_GPIO_Port, LED_R_Pin, GPIO_PIN_SET);
        return;
      }

    }

  }
}
/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{

  /* USER CODE BEGIN 1 */

  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_DMA_Init();
  MX_TIM4_Init();
  MX_TIM1_Init();
  MX_TIM5_Init();
  MX_USART1_UART_Init();
  /* USER CODE BEGIN 2 */

  HAL_TIM_PWM_Start(&htim5, TIM_CHANNEL_2);
  HAL_GPIO_WritePin(LED_B_GPIO_Port, LED_B_Pin, GPIO_PIN_RESET);
  HAL_GPIO_WritePin(LED_R_GPIO_Port, LED_R_Pin, GPIO_PIN_RESET);
  HAL_TIM_PWM_Start(&htim1, TIM_CHANNEL_1);
  __HAL_TIM_MOE_ENABLE(&htim1);
  __HAL_TIM_SET_COMPARE(&htim1, TIM_CHANNEL_1, 500);
  HAL_TIM_Base_Start_IT(&htim5);
  HAL_UARTEx_ReceiveToIdle_DMA(&huart1,(uint8_t *)rec,sizeof(rec));
  __HAL_DMA_DISABLE_IT(huart1.hdmarx,DMA_IT_HT);
  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  while (1)
  {
    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */
  }
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Configure the main internal regulator output voltage
  */
  __HAL_RCC_PWR_CLK_ENABLE();
  __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE1);

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSE;
  RCC_OscInitStruct.HSEState = RCC_HSE_ON;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSE;
  RCC_OscInitStruct.PLL.PLLM = 6;
  RCC_OscInitStruct.PLL.PLLN = 168;
  RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV2;
  RCC_OscInitStruct.PLL.PLLQ = 4;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV4;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV2;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_5) != HAL_OK)
  {
    Error_Handler();
  }
}

/* USER CODE BEGIN 4 */
void HAL_GPIO_EXTI_Callback(uint16_t GPIO_Pin) {

  static uint32_t time = 0;
  int32_t time2 = HAL_GetTick();
  if (time2-time < 300) return;
  time = time2;



  static uint32_t angle=0;
  static uint8_t dir=0;
  if (angle==2000) dir=1;
  else if (angle==0) dir=0;
  if (dir == 0) {
    angle+=400;
  }
  else if (dir == 1) {
    angle-=400;
  }
  __HAL_TIM_SET_COMPARE(&htim1, TIM_CHANNEL_1, 500+angle);

}

void HAL_TIM_PeriodElapsedCallback(TIM_HandleTypeDef *htim)
{
  if (htim->Instance != TIM5) return;
  if (!pwm_on) return;

  static uint16_t ccr = 0;
  static int8_t   dir = 1;

  ccr += dir;
  if (ccr >= 1000) { ccr = 1000; dir = -1; }
  if (ccr ==  0)   { ccr =  0;   dir =  1; }

  __HAL_TIM_SET_COMPARE(&htim5, TIM_CHANNEL_2, ccr);
}
/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}
#ifdef USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
